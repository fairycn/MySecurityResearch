<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  class cfgm_header_tags {

    const CODE = 'header_tags';
    const DIRECTORY = DIR_FS_CATALOG . 'includes/modules/header_tags/';
    const LANGUAGE_DIRECTORY = DIR_FS_CATALOG . 'includes/languages/';
    const KEY = 'MODULE_HEADER_TAGS_INSTALLED';
    const TITLE = MODULE_CFG_MODULE_HEADER_TAGS_TITLE;
    const TEMPLATE_INTEGRATION = true;

  }
