<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  class cfgm_currencies {

    const CODE = 'currencies';
    const DIRECTORY = DIR_FS_ADMIN . 'includes/modules/currencies/';
    const LANGUAGE_DIRECTORY = DIR_FS_ADMIN . 'includes/languages/';
    const KEY = 'MODULE_ADMIN_CURRENCIES_INSTALLED';
    const TITLE = MODULE_CFG_MODULE_CURRENCIES_TITLE;
    const TEMPLATE_INTEGRATION = false;

  }
