<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  class cfgm_boxes {

    const CODE = 'boxes';
    const DIRECTORY = DIR_FS_CATALOG . 'includes/modules/boxes/';
    const LANGUAGE_DIRECTORY = DIR_FS_CATALOG . 'includes/languages/';
    const KEY = 'MODULE_BOXES_INSTALLED';
    const TITLE = MODULE_CFG_MODULE_BOXES_TITLE;
    const TEMPLATE_INTEGRATION = true;

  }
