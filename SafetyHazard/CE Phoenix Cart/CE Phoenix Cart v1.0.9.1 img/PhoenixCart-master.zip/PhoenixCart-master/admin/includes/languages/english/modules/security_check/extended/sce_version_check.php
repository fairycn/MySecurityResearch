<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2022 Phoenix Cart

  Released under the GNU General Public License
*/

const MODULE_SECURITY_CHECK_EXTENDED_VERSION_CHECK_TITLE = 'Version Check';
const MODULE_SECURITY_CHECK_EXTENDED_VERSION_CHECK_ERROR = 'A new version check was performed more than 30 days ago. Please perform the check to see if a new version is available.';
