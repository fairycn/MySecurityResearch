<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2022 Phoenix Cart

  Released under the GNU General Public License
*/

const HEADING_TITLE = 'Products Expected';

const TABLE_HEADING_PRODUCTS = 'Products';
const TABLE_HEADING_DATE_EXPECTED = 'Date Expected';
const TABLE_HEADING_ACTION = 'Action';

const TEXT_INFO_DATE_EXPECTED = 'Date Expected: %s';
