<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2022 Phoenix Cart

  Released under the GNU General Public License
*/

const TEXT_COUNT_CUSTOMERS = 'Customers receiving this notification: %s';
const TEXT_PRODUCTS = 'Products';
const TEXT_SELECTED_PRODUCTS = 'Selected Products';

const JS_PLEASE_SELECT_PRODUCTS = 'Please select some products.';

const BUTTON_GLOBAL = 'Global';
const BUTTON_SELECT = '>>>';
const BUTTON_UNSELECT = '<<<';
const BUTTON_SUBMIT = 'Submit';
const BUTTON_CANCEL = 'Cancel';
