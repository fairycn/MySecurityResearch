<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2022 Phoenix Cart

  Released under the GNU General Public License
*/

const MODULE_ADMIN_DASHBOARD_ADMIN_LOGINS_TITLE = 'Last Administrator Logins';
const MODULE_ADMIN_DASHBOARD_ADMIN_LOGINS_DESCRIPTION = 'Show the last successful and failed administrator logins';
const MODULE_ADMIN_DASHBOARD_ADMIN_LOGINS_DATE = 'Date';
