<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2022 Phoenix Cart

  Released under the GNU General Public License
*/

const MODULE_ADMIN_DASHBOARD_CUSTOMERS_TITLE = 'Customers';
const MODULE_ADMIN_DASHBOARD_CUSTOMERS_DESCRIPTION = 'Show the newest customers';

const MODULE_ADMIN_DASHBOARD_CUSTOMERS_DATE = 'Date';
