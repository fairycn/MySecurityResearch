<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

const MODULE_SECURITY_CHECK_EXTENDED_SHOPSIDE_CHECKLIST_TITLE = 'User Checklist';
const MODULE_SECURITY_CHECK_EXTENDED_SHOPSIDE_CHECKLIST_MESSAGE = 'See our online <a target="_blank" rel="noreferrer" href="https://github.com/CE-PhoenixCart/PhoenixCart#user-checklist"><u>User Checklist</u></a> for a basic list of tasks you should perform.';
