<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  define('BOX_HEADING_TOOLS', '<i data-content="Tools" data-toggle="popover" data-placement="left" class="fas fa-tools fa-fw mr-1"></i><span class="d-inline d-md-none">Tools</span>');
