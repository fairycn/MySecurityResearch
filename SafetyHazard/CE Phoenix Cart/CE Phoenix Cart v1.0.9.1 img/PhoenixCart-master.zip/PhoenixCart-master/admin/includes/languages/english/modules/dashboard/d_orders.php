<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2022 Phoenix Cart

  Released under the GNU General Public License
*/

const MODULE_ADMIN_DASHBOARD_ORDERS_TITLE = 'Orders';
const MODULE_ADMIN_DASHBOARD_ORDERS_DESCRIPTION = 'Show the latest orders';
const MODULE_ADMIN_DASHBOARD_ORDERS_TOTAL = 'Total';
const MODULE_ADMIN_DASHBOARD_ORDERS_DATE = 'Date';
const MODULE_ADMIN_DASHBOARD_ORDERS_ORDER_STATUS = 'Status';
