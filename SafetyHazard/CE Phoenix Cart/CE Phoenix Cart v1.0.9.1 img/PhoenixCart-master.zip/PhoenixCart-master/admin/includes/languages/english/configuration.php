<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

const TABLE_HEADING_CONFIGURATION_TITLE = 'Title';
const TABLE_HEADING_CONFIGURATION_VALUE = 'Value';
const TABLE_HEADING_ACTION = 'Action';

const TEXT_INFO_EDIT_INTRO = 'Please make any necessary changes';
const TEXT_INFO_DATE_ADDED = 'Date Added:';
const TEXT_INFO_LAST_MODIFIED = 'Last Modified:';

const WARNING_INVALID_USE_FUNCTION = 'The use function (%s) for "%s" is invalid.';
