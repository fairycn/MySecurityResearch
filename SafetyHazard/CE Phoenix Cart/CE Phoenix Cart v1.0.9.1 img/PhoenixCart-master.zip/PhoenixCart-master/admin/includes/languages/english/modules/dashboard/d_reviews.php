<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2022 Phoenix Cart

  Released under the GNU General Public License
*/

const MODULE_ADMIN_DASHBOARD_REVIEWS_TITLE = 'Reviews';
const MODULE_ADMIN_DASHBOARD_REVIEWS_DESCRIPTION = 'Show the latest reviews';
const MODULE_ADMIN_DASHBOARD_REVIEWS_REVIEWER = 'Reviewer';
const MODULE_ADMIN_DASHBOARD_REVIEWS_DATE = 'Date';
const MODULE_ADMIN_DASHBOARD_REVIEWS_RATING = 'Rating';
const MODULE_ADMIN_DASHBOARD_REVIEWS_REVIEW_STATUS = 'Status';
