<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2022 Phoenix Cart

  Released under the GNU General Public License
*/

const MODULE_ADMIN_DASHBOARD_TOTAL_REVENUE_TITLE = 'Total Revenue Chart';
const MODULE_ADMIN_DASHBOARD_TOTAL_REVENUE_DESCRIPTION = 'Show the total revenue chart of the last X days';

const MODULE_ADMIN_DASHBOARD_TOTAL_REVENUE_CHART_LINK = 'Total Revenue';
