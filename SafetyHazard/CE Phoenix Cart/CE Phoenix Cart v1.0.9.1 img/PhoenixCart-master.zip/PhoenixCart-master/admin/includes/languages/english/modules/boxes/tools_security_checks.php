<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2022 Phoenix Cart

  Released under the GNU General Public License
*/

const MODULES_ADMIN_MENU_TOOLS_SECURITY_CHECKS = 'Security Checks';
