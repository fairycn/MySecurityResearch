<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2022 Phoenix Cart

  Released under the GNU General Public License
*/

const ERROR_NO_DEFAULT_CURRENCY_DEFINED = <<<'EOT'
<strong>Error:</strong> There is currently no default currency set. Please set one at: Administration Tool-&gt;Localization-&gt;Currencies
EOT;
