<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2022 Phoenix Cart

  Released under the GNU General Public License
*/

const ERROR_NO_DEFAULT_LANGUAGE_DEFINED = <<<'EOT'
<strong>Error:</strong> There is currently no default language set. Please set one at: Administration Tool->Localization->Languages
EOT;
