<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2022 Phoenix Cart

  Released under the GNU General Public License
*/

const MODULE_ADMIN_DASHBOARD_SECURITY_CHECKS_TITLE = 'Security Checks';
const MODULE_ADMIN_DASHBOARD_SECURITY_CHECKS_DESCRIPTION = 'Run security checks';
const MODULE_ADMIN_DASHBOARD_SECURITY_CHECKS_SUCCESS = 'This is a properly configured installation of CE Phoenix!';
