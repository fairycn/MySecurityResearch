<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2022 Phoenix Cart

  Released under the GNU General Public License
*/

const WARNING_INSTALL_DIRECTORY_EXISTS = 'Installation directory exists at: ' . DIR_FS_CATALOG . 'install. Please remove this directory for security reasons.';
